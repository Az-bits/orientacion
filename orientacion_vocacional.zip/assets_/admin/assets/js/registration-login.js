 $.backstretch([
  "../assets/admin/assets/images/timelines/logo_zoom.png"
], {duration: 3000, fade: 750});