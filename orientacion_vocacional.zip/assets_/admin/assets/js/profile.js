$(document).ready(function(){

    "use strict";

	$(".profile-events-scroll").niceScroll({
        cursorcolor: "rgb(231, 231, 231)",
        cursorborder: "0px solid #fff",
        cursorborderradius: "0px",
        cursorwidth: "3px"
    });

	$(".profile-posts-scroll").niceScroll({
        cursorcolor: "rgb(231, 231, 231)",
        cursorborder: "0px solid #fff",
        cursorborderradius: "0px",
        cursorwidth: "3px"
    });

	$(".profile-notifi-scroll").niceScroll({
        cursorcolor: "rgb(231, 231, 231)",
        cursorborder: "0px solid #fff",
        cursorborderradius: "0px",
        cursorwidth: "3px"
    });
});