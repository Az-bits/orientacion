<?php $obj=$this->db->get("institucion")->row(); ?>
